# SmartPark360: Professional Parking & Valet Management

SmartPark360 is a complete, real-time parking ecosystem designed for modern commercial premises. It features a robust Node.js backend with dynamic pricing logic and a high-performance React dashboard for facility operators.

## 🚀 Features

- **Live Occupancy Tracking**: Visual grid representing slot availability updated via WebSockets.
- **Dynamic AI Pricing**: Automated fee calculation based on duration, vehicle type, and peak hours.
- **Role-Based Access**: Specialized interfaces for Administrators, Valet Attendants, and Users.
- **Valet Workflow**: Task management system for tracking vehicle retrieval and drop-offs.
- **Interactive Analytics**: Revenue and occupancy trends visualized with Recharts.

## 🛠️ Prerequisites

- **Node.js** (v16 or higher)
- **NPM** (v8 or higher)

## 📦 Installation & Setup

1. **Clone the repository and install all dependencies**:
    