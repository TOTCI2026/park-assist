import React, { useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';
import { 
  LayoutDashboard, 
  Car, 
  UserCircle, 
  Settings, 
  LogOut, 
  Activity,
  MapPin,
  Clock
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line 
} from 'recharts';

const socket = io('http://localhost:5000');

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')));
  const [view, setView] = useState('DASHBOARD');
  const [loginData, setLoginData] = useState({ email: 'admin@park.com', password: 'password123' });
  const [error, setError] = useState('');

  // App State
  const [stats, setStats] = useState({ totalRevenue: 0, activeParkings: 0, availableSlots: 0 });
  const [slots, setSlots] = useState([]);
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    if (token) {
        fetchData();
        socket.on('booking_update', () => fetchData());
        socket.on('valet_update', () => fetchData());
    }
    return () => {
        socket.off('booking_update');
        socket.off('valet_update');
    };
  }, [token]);

  const fetchData = async () => {
    try {
        const config = { headers: { Authorization: `Bearer ${token}` } };
        const [statsRes, slotsRes] = await Promise.all([
            axios.get('http://localhost:5000/api/admin/stats', config),
            axios.get('http://localhost:5000/api/parking/slots', config)
        ]);
        setStats(statsRes.data);
        setSlots(slotsRes.data);
    } catch (e) {
        console.error("Fetch Error", e);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
        const res = await axios.post('http://localhost:5000/api/auth/login', loginData);
        localStorage.setItem('token', res.data.token);
        localStorage.setItem('user', JSON.stringify(res.data));
        setToken(res.data.token);
        setUser(res.data);
    } catch (err) {
        setError('Invalid credentials');
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    setToken(null);
    setUser(null);
  };

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <form onSubmit={handleLogin} className="bg-white p-8 rounded-xl shadow-2xl w-96">
          <h1 className="text-3xl font-bold text-center mb-6 text-indigo-600">SmartPark360</h1>
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          <div className="space-y-4">
            <input 
              className="w-full p-3 border rounded focus:ring-2 focus:ring-indigo-400 outline-none" 
              placeholder="Email" 
              value={loginData.email}
              onChange={e => setLoginData({...loginData, email: e.target.value})}
            />
            <input 
              type="password"
              className="w-full p-3 border rounded focus:ring-2 focus:ring-indigo-400 outline-none" 
              placeholder="Password" 
              value={loginData.password}
              onChange={e => setLoginData({...loginData, password: e.target.value})}
            />
            <button className="w-full bg-indigo-600 text-white py-3 rounded font-bold hover:bg-indigo-700 transition">
              Sign In
            </button>
          </div>
          <div className="mt-4 text-xs text-center text-gray-500">
            Hint: admin@park.com / password123<br/>
            valet@park.com / password123
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-indigo-900 text-white flex flex-col">
        <div className="p-6 text-2xl font-bold border-b border-indigo-800">SmartPark360</div>
        <nav className="flex-1 p-4 space-y-2">
          <NavItem icon={<LayoutDashboard size={20}/>} label="Dashboard" active={view === 'DASHBOARD'} onClick={() => setView('DASHBOARD')} />
          <NavItem icon={<MapPin size={20}/>} label="Parking Map" active={view === 'MAP'} onClick={() => setView('MAP')} />
          {user.role === 'ADMIN' && <NavItem icon={<Activity size={20}/>} label="Analytics" active={view === 'ANALYTICS'} onClick={() => setView('ANALYTICS')} />}
          {user.role === 'ATTENDANT' && <NavItem icon={<Car size={20}/>} label="Valet Tasks" active={view === 'VALET'} onClick={() => setView('VALET')} />}
        </nav>
        <div className="p-4 border-t border-indigo-800">
          <div className="flex items-center gap-3 mb-4">
            <UserCircle size={32} />
            <div>
              <p className="text-sm font-bold">{user.name}</p>
              <p className="text-xs text-indigo-300 capitalize">{user.role}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="flex items-center gap-2 text-sm text-indigo-300 hover:text-white transition">
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <header className="bg-white h-16 shadow-sm flex items-center justify-between px-8">
          <h2 className="text-xl font-semibold text-gray-800">{view}</h2>
          <div className="flex items-center gap-4">
             <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold ring-1 ring-green-200">System Online</span>
          </div>
        </header>

        <main className="p-8">
          {view === 'DASHBOARD' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard label="Live Revenue" value={`$${stats.totalRevenue}`} color="bg-green-500" />
                <StatCard label="Active Parkings" value={stats.activeParkings} color="bg-blue-500" />
                <StatCard label="Available Slots" value={stats.availableSlots} color="bg-purple-500" />
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm">
                <h3 className="text-lg font-bold mb-4">Real-Time Occupancy Map</h3>
                <div className="grid grid-cols-5 md:grid-cols-10 gap-4">
                   {slots.map(slot => (
                     <div 
                      key={slot.id} 
                      className={`h-16 rounded-lg flex flex-col items-center justify-center border-2 transition-all ${
                        slot.status === 'AVAILABLE' ? 'border-green-200 bg-green-50 text-green-700' : 'border-red-200 bg-red-50 text-red-700'
                      }`}
                     >
                       <span className="text-xs font-bold">{slot.slotNumber}</span>
                       <Car size={16} className={slot.status === 'AVAILABLE' ? 'opacity-20' : 'opacity-100'} />
                     </div>
                   ))}
                </div>
              </div>
            </div>
          )}

          {view === 'ANALYTICS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-xl shadow-sm h-96">
                <h3 className="font-bold mb-4">Revenue Trend (Mock)</h3>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={mockChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="revenue" stroke="#4f46e5" strokeWidth={3} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm h-96">
                <h3 className="font-bold mb-4">Slot Utilization</h3>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mockChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="utilization" fill="#818cf8" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {view === 'MAP' && (
             <div className="bg-white p-8 rounded-xl text-center">
                <MapPin size={48} className="mx-auto text-indigo-400 mb-4" />
                <h3 className="text-xl font-bold">Interactive Facility Map</h3>
                <p className="text-gray-500 mt-2">Level 1 - Main Entrance Premise</p>
                <div className="mt-8 relative border-4 border-gray-100 rounded-2xl p-10 bg-gray-50 max-w-2xl mx-auto">
                    {/* Placeholder for complex SVG map */}
                    <div className="grid grid-cols-4 gap-8">
                       {[...Array(8)].map((_, i) => (
                         <div key={i} className="h-24 bg-white border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-400">
                            Slot B-{i+1}
                         </div>
                       ))}
                    </div>
                </div>
             </div>
          )}

          {view === 'VALET' && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold">Assigned Valet Tasks</h3>
              <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                <table className="w-full text-left">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="p-4 border-b">Vehicle</th>
                      <th className="p-4 border-b">Request Type</th>
                      <th className="p-4 border-b">Time</th>
                      <th className="p-4 border-b">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="p-4 font-mono">ABC-1234</td>
                      <td className="p-4"><span className="bg-orange-100 text-orange-700 px-2 py-1 rounded text-xs">PICKUP</span></td>
                      <td className="p-4 text-sm text-gray-500">2 mins ago</td>
                      <td className="p-4">
                        <button className="bg-indigo-600 text-white px-4 py-1 rounded text-sm hover:bg-indigo-700">Confirm Pickup</button>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-4 font-mono">XYZ-9876</td>
                      <td className="p-4"><span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">RETURN</span></td>
                      <td className="p-4 text-sm text-gray-500">Just Now</td>
                      <td className="p-4">
                        <button className="bg-green-600 text-white px-4 py-1 rounded text-sm hover:bg-green-700">Deliver Vehicle</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

const NavItem = ({ icon, label, active, onClick }) => (
  <div 
    onClick={onClick}
    className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
      active ? 'bg-indigo-800 text-white' : 'text-indigo-300 hover:bg-indigo-800/50 hover:text-white'
    }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </div>
);

const StatCard = ({ label, value, color }) => (
  <div className="bg-white p-6 rounded-xl shadow-sm flex items-center gap-4 border-l-4 border-l-transparent hover:border-l-indigo-500 transition-all">
    <div className={`p-3 rounded-lg ${color} text-white`}>
      <Activity size={24} />
    </div>
    <div>
      <p className="text-sm text-gray-500 font-medium">{label}</p>
      <p className="text-2xl font-bold text-gray-800">{value}</p>
    </div>
  </div>
);

const mockChartData = [
  { name: 'Mon', revenue: 400, utilization: 65 },
  { name: 'Tue', revenue: 300, utilization: 50 },
  { name: 'Wed', revenue: 500, utilization: 80 },
  { name: 'Thu', revenue: 700, utilization: 90 },
  { name: 'Fri', revenue: 1200, utilization: 98 },
  { name: 'Sat', revenue: 1500, utilization: 100 },
  { name: 'Sun', revenue: 1100, utilization: 85 },
];

export default App;
