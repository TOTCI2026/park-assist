/**
 * Advanced Pricing Engine for SmartPark360
 */
const calculateParkingFee = (entryTime, vehicleType) => {
    const exitTime = new Date();
    const durationMs = exitTime - new Date(entryTime);
    const durationHours = Math.ceil(durationMs / (1000 * 60 * 60));

    // Base rates
    const rates = {
        SEDAN: 10,
        SUV: 15,
        EV: 12
    };

    const baseRate = rates[vehicleType] || 10;
    
    // Peak Hour Multiplier (Example: 5pm - 9pm)
    const currentHour = new Date().getHours();
    const isPeak = currentHour >= 17 && currentHour <= 21;
    const multiplier = isPeak ? 1.5 : 1.0;

    let total = durationHours * baseRate * multiplier;

    // Minimum 1 hour charge
    return Math.max(total, baseRate);
};

module.exports = { calculateParkingFee };
