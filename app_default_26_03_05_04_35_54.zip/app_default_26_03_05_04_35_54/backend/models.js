const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: path.join(__dirname, 'database.sqlite'),
    logging: false
});

const User = sequelize.define('User', {
    id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
    name: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, unique: true, allowNull: false },
    password: { type: DataTypes.STRING, allowNull: false },
    role: { type: DataTypes.ENUM('ADMIN', 'ATTENDANT', 'USER'), defaultValue: 'USER' }
});

const ParkingSlot = sequelize.define('ParkingSlot', {
    id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
    slotNumber: { type: DataTypes.STRING, unique: true },
    type: { type: DataTypes.ENUM('SEDAN', 'SUV', 'EV'), defaultValue: 'SEDAN' },
    status: { type: DataTypes.ENUM('AVAILABLE', 'OCCUPIED', 'RESERVED'), defaultValue: 'AVAILABLE' },
    floor: { type: DataTypes.INTEGER, defaultValue: 1 }
});

const Booking = sequelize.define('Booking', {
    id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
    vehiclePlate: { type: DataTypes.STRING, allowNull: false },
    entryTime: { type: DataTypes.DATE, defaultValue: Sequelize.NOW },
    exitTime: { type: DataTypes.DATE },
    totalFee: { type: DataTypes.FLOAT, defaultValue: 0 },
    status: { type: DataTypes.ENUM('ACTIVE', 'COMPLETED', 'CANCELLED'), defaultValue: 'ACTIVE' },
    valetStatus: { type: DataTypes.ENUM('NONE', 'PICKUP_REQUESTED', 'IN_VALET', 'RETURN_REQUESTED', 'DELIVERED'), defaultValue: 'NONE' }
});

// Relationships
User.hasMany(Booking);
Booking.belongsTo(User);
ParkingSlot.hasMany(Booking);
Booking.belongsTo(ParkingSlot);

module.exports = { sequelize, User, ParkingSlot, Booking };
