const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { sequelize, User, ParkingSlot, Booking } = require('./models');
const { calculateParkingFee } = require('./services/pricingService');

dotenv.config();
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: "*" }
});

app.use(cors());
app.use(express.json());

// --- Authentication Middleware ---
const authenticate = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(401).json({ error: 'No token provided' });
    
    jwt.verify(token.split(' ')[1], process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(403).json({ error: 'Failed to authenticate' });
        req.user = decoded;
        next();
    });
};

// --- Routes ---

// Auth: Register & Login
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, password, role } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({ name, email, password: hashedPassword, role });
        res.status(201).json({ message: 'User created' });
    } catch (e) {
        res.status(400).json({ error: e.message });
    }
});

app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    if (user && await bcrypt.compare(password, user.password)) {
        const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, process.env.JWT_SECRET);
        res.json({ token, role: user.role, name: user.name });
    } else {
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

// Parking: Get All Slots
app.get('/api/parking/slots', async (req, res) => {
    const slots = await ParkingSlot.findAll();
    res.json(slots);
});

// Booking: Create New Entry
app.post('/api/bookings/entry', authenticate, async (req, res) => {
    try {
        const { vehiclePlate, slotId, vehicleType } = req.body;
        
        const slot = await ParkingSlot.findByPk(slotId);
        if (!slot || slot.status !== 'AVAILABLE') {
            return res.status(400).json({ error: 'Slot not available' });
        }

        const booking = await Booking.create({
            vehiclePlate,
            ParkingSlotId: slotId,
            UserId: req.user.id,
            valetStatus: req.body.useValet ? 'PICKUP_REQUESTED' : 'NONE'
        });

        await slot.update({ status: 'OCCUPIED' });
        
        io.emit('booking_update', { message: 'New booking created', booking });
        res.status(201).json(booking);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Booking: Exit & Pricing
app.put('/api/bookings/exit/:id', authenticate, async (req, res) => {
    try {
        const booking = await Booking.findByPk(req.params.id, { include: [ParkingSlot] });
        if (!booking) return res.status(404).json({ error: 'Booking not found' });

        const fee = calculateParkingFee(booking.entryTime, booking.ParkingSlot.type);
        
        await booking.update({
            exitTime: new Date(),
            totalFee: fee,
            status: 'COMPLETED'
        });

        await ParkingSlot.update({ status: 'AVAILABLE' }, { where: { id: booking.ParkingSlotId } });

        io.emit('booking_update', { message: 'Booking completed', booking });
        res.json({ message: 'Exit processed', fee });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Admin: Analytics
app.get('/api/admin/stats', authenticate, async (req, res) => {
    if (req.user.role !== 'ADMIN') return res.status(403).json({ error: 'Unauthorized' });
    
    const totalRevenue = await Booking.sum('totalFee', { where: { status: 'COMPLETED' } });
    const activeParkings = await Booking.count({ where: { status: 'ACTIVE' } });
    const availableSlots = await ParkingSlot.count({ where: { status: 'AVAILABLE' } });
    
    res.json({ totalRevenue: totalRevenue || 0, activeParkings, availableSlots });
});

// Valet: Update Task
app.put('/api/valet/update/:id', authenticate, async (req, res) => {
    const { status } = req.body;
    const booking = await Booking.findByPk(req.params.id);
    await booking.update({ valetStatus: status });
    io.emit('valet_update', { bookingId: req.params.id, status });
    res.json({ success: true });
});

// --- Server Initialization ---
const PORT = process.env.PORT || 5000;

sequelize.sync({ force: true }).then(async () => {
    console.log('Database synced');
    
    // Seed Data
    const hashedPassword = await bcrypt.hash('password123', 10);
    await User.create({ name: 'Admin User', email: 'admin@park.com', password: hashedPassword, role: 'ADMIN' });
    await User.create({ name: 'Valet John', email: 'valet@park.com', password: hashedPassword, role: 'ATTENDANT' });
    
    // Seed Parking Slots
    const slots = [];
    for(let i=1; i<=20; i++) {
        slots.push({ slotNumber: `A${i}`, floor: 1, type: i % 5 === 0 ? 'SUV' : 'SEDAN' });
    }
    await ParkingSlot.bulkCreate(slots);

    server.listen(PORT, () => {
        console.log(`SmartPark360 running on http://localhost:${PORT}`);
    });
});
